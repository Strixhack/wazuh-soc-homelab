# Attack 06 — Registry Run Key Persistence

## Overview
| Field | Details |
|-------|---------|
| MITRE ID | T1547.001 |
| Tactic | Persistence |
| Severity | Critical |
| Tool | reg.exe |
| Wazuh Rule | 92302 — Level 6 |
| Target | Windows 10 VM |

## Commands

### Windows VM — PowerShell as Administrator
```powershell
# Add malicious Run key entry
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurityUpdate" /t REG_SZ /d "C:\SOC-Lab\update.exe" /f

# Verify entry added
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run"

# Check Sysmon EID 13
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" | Where-Object {$_.Id -eq 13} | Select-Object -First 3 | Format-List TimeCreated, Message

# Cleanup
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurityUpdate" /f
```

## Detection
- **Rule ID:** 92302 — Level 6
- **Sysmon EID:** 13 (Registry Value Set)
- **Dashboard Search:** SecurityUpdate OR CurrentVersion\Run

---

# Attack 07 — Network Port Scanning

## Overview
| Field | Details |
|-------|---------|
| MITRE ID | T1046 |
| Tactic | Discovery |
| Severity | Medium |
| Tool | Nmap |
| Wazuh Rule | 100008 — Level 10 |
| Attacker | Kali Linux (192.168.56.106) |

## Commands

### Windows VM — Enable Firewall Logging
```powershell
netsh advfirewall set allprofiles logging droppedconnections enable
netsh advfirewall set allprofiles logging allowedconnections enable
netsh advfirewall set allprofiles logging filename "C:\Windows\System32\LogFiles\Firewall\pfirewall.log"
Restart-Service WazuhSvc
```

### Kali Linux
```bash
nmap -sS -sV 192.168.56.105
nmap -A -T4 192.168.56.105
nmap -p- -T4 192.168.56.105
```

## Detection
- **Rule ID:** 100008 — Level 10
- **Dashboard Search:** 192.168.56.106 OR port scan

---

# Attack 08 — File Integrity Violation

## Overview
| Field | Details |
|-------|---------|
| MITRE ID | T1565.001 |
| Tactic | Impact |
| Severity | High |
| Tool | Wazuh FIM |
| Wazuh Rule | 550/554 — Level 7 |

## Commands

### Windows VM — PowerShell as Administrator
```powershell
# Restart agent to build FIM baseline
Restart-Service WazuhSvc

# Wait 3 minutes for baseline
Start-Sleep -Seconds 180

# Create sensitive file — triggers Rule 554
echo "db_password=Admin123" > C:\Temp\config.txt

# Tamper with file — triggers Rule 550
Start-Sleep -Seconds 15
echo "TAMPERED BY ATTACKER" >> C:\Temp\config.txt

# Cleanup
Remove-Item C:\Temp\config.txt -Force
```

## Detection
- **Rule ID:** 554 (new file), 550 (modified file)
- **Dashboard Search:** syscheck OR integrity checksum

---

# Attack 09 — Local Account Discovery

## Overview
| Field | Details |
|-------|---------|
| MITRE ID | T1087.001 |
| Tactic | Discovery |
| Severity | Low |
| Tool | net.exe / PowerShell |
| Wazuh Rule | 100009 — Level 8 |

## Commands

### Windows VM
```powershell
net user
net localgroup administrators
Get-LocalUser | Select Name, Enabled, LastLogon
Get-LocalGroup
query user
whoami /all
```

### Kali Linux — Remote Enumeration
```bash
crackmapexec smb 192.168.56.105 -u labuser -p Summer2024! --users
crackmapexec smb 192.168.56.105 -u labuser -p Summer2024! --groups
```

## Detection
- **Rule ID:** 100009 — Level 8
- **Dashboard Search:** net user OR Get-LocalUser

---

# Attack 10 — Event Log Clearing

## Overview
| Field | Details |
|-------|---------|
| MITRE ID | T1070.001 |
| Tactic | Defense Evasion |
| Severity | Critical |
| Tool | wevtutil.exe |
| Wazuh Rule | 100010 — Level 14 |

## Objective
Simulate an attacker clearing Windows event logs to destroy forensic evidence, proving centralized SIEM logging value — all logs already forwarded to Wazuh and safe.

## Commands

### Windows VM — PowerShell as Administrator
```powershell
# Clear all Windows event logs
wevtutil cl Security
wevtutil cl System
wevtutil cl Application
wevtutil cl "Windows PowerShell"

# Verify cleared
wevtutil gli Security
```

## Detection
- **Rule ID:** 100010, 100011 — Level 14 Critical
- **EID:** 1102 (Security log cleared), 104 (System log cleared)
- **Dashboard Search:** wevtutil OR 1102 OR log cleared

## Key Finding
Even after clearing all local logs, Wazuh SIEM retained all forwarded events — proving the value of centralized log management in a real SOC environment.
